def find_combination(n):
    # 입력값에 10을 곱합니다
    n *= 10

    # 가능한 조합을 찾기 위해 반복문을 사용합니다
    for count_25 in range(n // 25, -1, -1):
        for count_15 in range((n - count_25 * 25) // 15, -1, -1):
            count_10 = (n - count_25 * 25 - count_15 * 15) // 10

            # 나머지가 없는 조합을 찾으면 출력하고 함수 종료
            if count_25 * 25 + count_15 * 15 + count_10 * 10 == n:
                print(count_10 + count_15 + count_25)
                return

user_input = int(input())
# 함수 호출
find_combination(user_input)
