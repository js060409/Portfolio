n = int(input())
cake = [1] * (n+1)
cake[0] = 0

student = list(map(int, input().split()))

use = [0] * 3
last = n

for i in student :
    if i == 1 :
        if cake[i+1] == 0 :
            use[0] += 1
        else :
            use[1] += 1
        cake[1] = 0
        
    elif i == last :
        if cake[i-1] == 0 :
            use[0] += 1
        else :
            use[1] += 1
        cake[last] = 0
        
    elif cake[i-1] == 0 and cake[i+1] == 0 :
        use[0] += 1
        cake[i] = 0
    elif (cake[i-1] == 0 and cake[i+1] == 1) or (cake[i-1] == 1 and cake[i+1] == 0) :
        use[1] += 1
        cake[i] = 0
    else :
        use[2] += 1
        cake[i] = 0

print(use[1], use[2])
