n, m, k, t = map(int, input().split())  # 전체 관광지 수, 선생님이 정해준 관광지 수, 학생 수, 스탬프투어 시간
tour_times = list(map(int, input().split()))  # 각 관광지의 관람 시간
students_tour_order = [list(map(int, input().split())) for _ in range(k)]  # 각 학생의 관광지 관람 순서
t = t-5
def count_gifted_students(t, tour_times, student_order):
    remaining_time = t
    for index in student_order:
        remaining_time -= (tour_times[index - 1] + 5)  # 각 관광지 관람 시간에 5분을 추가하여 이동 시간 계산
        if remaining_time < 0:
            return False  # 남은 시간이 음수가 되면 더 이상 관람할 수 없음
    return True

gifted_students = 0

for student_order in students_tour_order:
    if count_gifted_students(t, tour_times, student_order):
        gifted_students += 1

print(gifted_students)
