from itertools import permutations

n, m, t = map(int, input().split())  # 전체 관광지 수, 선생님이 정해준 관광지 수, 스탬프투어 시간
tour_times = list(map(int, input().split()))  # 각 관광지의 관람 시간
t = t-5
possible_orders = list(permutations(range(1, n + 1), m))  # 가능한 관광지 순서의 가짓수 계산

def count_valid_orders(orders, t, tour_times):
    valid_orders = 0
    for order in orders:
        remaining_time = t
        for index in order:
            remaining_time -= (tour_times[index - 1] + 5)  # 각 관광지 관람 시간에 5분을 추가하여 이동 시간 계산
            if remaining_time < 0:
                break  # 남은 시간이 음수가 되면 더 이상 관람할 수 없음
        else:
            valid_orders += 1  # for 문이 정상적으로 종료되면 유효한 관광지 순서
    return valid_orders

result = count_valid_orders(possible_orders, t, tour_times)
print(result)
