from itertools import permutations

def calculate_max_time(arrival_time, departure_time, travel_times):
    locations = len(travel_times)
    
    arrival_minutes = int(arrival_time.split(':')[0]) * 60 + int(arrival_time.split(':')[1])
    departure_minutes = int(departure_time.split(':')[0]) * 60 + int(departure_time.split(':')[1])
    
    max_stay_times = []
    for perm in permutations(range(1, locations)): 
        total_time = 0
        current_location = 0
        for next_location in perm:
            total_time += travel_times[current_location][next_location]
            current_location = next_location
        total_time += travel_times[current_location][0]  
        max_stay_times.append(departure_minutes - arrival_minutes - total_time)
    
    return max(max_stay_times)

arrival_time = input().strip()
departure_time = input().strip()
travel_times = [list(map(int, input().split())) for _ in range(6)]

result = calculate_max_time(arrival_time, departure_time, travel_times)

hours = result // 60
minutes = result % 60
print(f"{hours:02d}:{minutes:02d}")